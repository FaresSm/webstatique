## <abbr> : représentation d'une abbréviation ou d'un acronyme
https://developer.mozilla.org/fr/docs/Web/HTML/Element/abbr

## id : définition d'un identifiant unique
https://developer.mozilla.org/fr/docs/Web/HTML/Attributs_universels/id

## Table des caractères spéciaux
https://dev.w3.org/html5/html-author/charref
https://alexandre.alapetite.fr/doc-alex/alx_special.html

## Faire un lien vers un endroit précis de la page
https://www.alsacreations.com/astuce/lire/5-lien-precis-page-ancre-anchor-diese.html
