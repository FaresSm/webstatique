# HTML

## Logo :
Il faut ajouter un hyperlien vers index.html

Pour les guillemets typographiques, utilisation de :
- &laquo;&nbsp;
- &nbsp;&raquo;

## Liste numérotée "les langages"
Ajouter une ancre sur les hyperliens HTML et CSS, qui pointent directement sur le bon endroit dans la page. Il faudra ajouter un id "html" sur le titre "Le HTML" et un id "css" sur le titre "Le CSS".

## Liste des éditeurs de texte
Ajouter les hyperliens en les ouvrant dans un nouvel onglet + ajout d'un attribut title avec le texte "Télécharger" suivi du nom de l'éditeur :
Brackets : https://brackets.io
Atom : https://atom.io
Sublime Text : https://www.sublimetext.com"

## Découverte de la balise abbr
Sur les mots HTML et CSS, dans les paragraphes de "Mes premiers pas sur le web", ajouter la balise abbr avec le texte :
HTML : HyperText Markup Language
CSS : Cascading Style Sheets

# CSS

## Styles de la page
Couleur du texte : #444

## Style des titres 1 et 2
Couleur : #32CBDD

## Style des hyperliens
Couleur : #028DB6
