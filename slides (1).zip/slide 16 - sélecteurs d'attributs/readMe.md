## CSS SLIDE 16 : Les sélecteurs d'attributs

* * *

En modifiant/créant les styles CSS : 

- Mettre les liens avec l'attribut target présent :
  - en lightgreen (color:lightgreen)
  - police grasse (font-weight:bold)
- Celui avec l'attribut target="_top" avec une taille de police à 3rem (font-size)