## CSS SLIDE 23 : Inline et block

* * *

En modifiant/créant les styles CSS et en vous aidant des documentations officielles: 

# Inline

- Entourer le texte en gras d'un bordure rouge
- Mettre les span avec une couleur de fond rose

# Block
- Encadrer les paragraphes d'une bordure verte
- Et les div avec une couleur de fond lightgrey