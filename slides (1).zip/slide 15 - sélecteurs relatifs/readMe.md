## CSS SLIDE 15 : Les sélecteurs relatifs
* * *

En modifiant/créant les styles CSS et en vous aidant des documentations officielles: 

## Global
- couleur du texte du body et des div en noir
- Couleur de fond du body et des div en lightgrey

## Texte :

- couleur du texte de tous les paragraphes du conteneur en rouge
- police grasse pour les paragraphes directement enfants du conteneur
- couleur du texte du paragraphe qui suit directement le conteneur en vert
- Les paragraphes qui suivent directement un titre de niveau 2 en majuscule
- Les paragraphes qui suivent un élément code ET ayant le même niveau que cet élément en rose

## DIV

- Les div directement enfants du body en jaune
- Les div qui suivent directement un titre de niveau 1 avec une bordure verte