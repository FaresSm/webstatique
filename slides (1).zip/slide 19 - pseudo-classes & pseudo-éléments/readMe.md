## CSS SLIDE 19 : Les pseudo-classes et pseudo-elements

* * *

En modifiant/créant les styles CSS et en vous aidant des documentations officielles: 

# Pseudo-classes

- Mettre tous les liens en rose
- Au survol des liens, augmentez la police à 1.5rem et passez la couleur à jaune
- Mettre les liens déjà visités en rose
- Au survol d'un paragraphe, mettre le fond en rouge

# Pseudo-éléments
- Faire une lettrine en augmentant la police de la première lettre des paragraphes à 1.8 rem
- Faire en sorte que les selections de l'utilisateur soient surlignées en jaune (vous pouvez commenter le survol du paragraphe en rouge)


- BONUS : Ajouter l'image [https://bitsofco.de/content/images/2017/03/icon_256.png avec une taille de 16px](https://d1nhio0ox7pgb.cloudfront.net/_img/g_collection_png/standard/16x16/ok.png) avant chaque titre de niveau 1.Ajoutez une marge à droite de 6px