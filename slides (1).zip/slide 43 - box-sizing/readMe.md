## CSS SLIDE 43 : box-sizing

* * *

- Mettre les div à une largeur de 500px avec une couleur de fond
- Mettre les h2 à 400px avec une bordure et une couleur de fond
- Pour les paragaphes:
  - ceux avec la classe .para1 :
    - 500px de large
    - une bordure visible
    - une couleur de fond visible
    - un padding de 15px
  - Ceux avec la classe .para2
    - 500px de large
    - une bordure visible
    - une couleur de fond visible
    - une margin de 15px
  - changer un box sizing à border box pour les paragraphes ayant la classe .box