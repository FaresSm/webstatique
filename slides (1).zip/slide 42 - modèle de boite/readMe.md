## CSS SLIDE 42 : modèle de boite

* * *

- Créer une div avec un titre et un paragraphe en lorem
  de largeur (width) 500px :
  - de couleur de fond (backgroud-color) au choix
  - avec une  bordure (border) 15px, de type au choix, de couleur au choix
  - avec une marge de 50px;