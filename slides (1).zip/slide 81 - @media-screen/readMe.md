## CSS SLIDE 81 : media queries

* * *

- Faire en sorte que la couleur du fond du body soit différente pour les ecrans :
  - supérieur à 1280px
  - entre 680 et 1280px
  - inférieur à 680px
