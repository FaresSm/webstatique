## CSS SLIDE 26 : @font-face

* * *

En modifiant/créant les styles CSS et en vous aidant des documentations officielles: 

- Mettre la police contenu dans le dossier font pour les titres de niveau 1.
- Référez-vous à la doc [https://developer.mozilla.org/fr/docs/Web/CSS/@font-face](https://developer.mozilla.org/fr/docs/Web/CSS/@font-face )