## CSS SLIDE 27 : Google font

* * *

En modifiant/créant les styles CSS et en vous aidant des documentations officielles: 

- Ajouter la police[https://fonts.google.com/specimen/Gloria+Hallelujah](Gloria Hallelujah) pour le titre et une autre police google font pour le texte
- BONUS : Utiliser deux méthodes différentes pour récupérer les polices du titre et du texte :
  - La première dans le fichier html
  - La seconde dans le fichier css